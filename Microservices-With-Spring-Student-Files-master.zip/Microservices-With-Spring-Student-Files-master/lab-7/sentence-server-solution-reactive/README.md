Special thanks to Jorge Centeno Fernández for contributing this reactive solution!
